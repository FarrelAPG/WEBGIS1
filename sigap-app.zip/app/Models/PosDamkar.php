<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PosDamkar extends Model
{
    //
}
